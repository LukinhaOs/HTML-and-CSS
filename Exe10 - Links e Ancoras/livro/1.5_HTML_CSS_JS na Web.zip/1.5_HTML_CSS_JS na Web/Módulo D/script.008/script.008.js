var velocity = 45.5
console.log(`A velocidade do seu carro é ${velocity}km por hora`)
if (velocity > 60) {
    console.log('Você ultrapassou a velocidade permitida! Multado(a)')
    console.log(`Velocidade máxima permitida 60km por hora. Sua velocidade percorrida ${velocity}km`)
}
console.log('Dirija sempre usando o sinto de segurança :)') 
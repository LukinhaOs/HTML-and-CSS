var pais = 'EUROPA'
if (pais == 'BRASIL') {
    console.log('Você é Brasileiro(a)')
}
else {
    console.log('Você é estrangeiro(a)')
}